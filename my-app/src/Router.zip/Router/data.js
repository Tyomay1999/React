const data = [
    {
        carName: 'Mersedes',
        model: 'GLE',
        id: 'mersedes'
    },
    {
        carName: 'Opel',
        model: 'Astra G',
        id: 'opel'
    },
    {
        carName: 'Kia',
        model: 'Forte',
        id: 'kia'
    },
    {
        carName: 'Nissan',
        model: 'Versa',
        id: 'nissan'
    }
]
const moto = [
    {
        carName: 'Suzuki',
        model: 'Hayabusa',
        id: 'suzuki'
    },
    {
        carName: 'Yamaha',
        model: 'R1',
        id: 'yamaha'
    },
    {
        carName: 'Kawasaki',
        model: 'KXF250',
        id: 'kawasaki'
    }
]
export {
    data,
    moto
}

