import React from 'react';
import './loading.css';

const Loading = () => {
    return(
        <div className="Loading">

        </div>
    )
}

export default Loading;